﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void CalculoVolume()
        {
            Double Volume, Raio, Altura;
            Double Pi = 3.14;

            Raio = Convert.ToDouble(textBox1.Text);
            Altura = Convert.ToDouble(textBox2.Text);


            Volume = Pi * (Raio * Raio) * Altura;

            Volumee.Text = Volume.ToString();

        }

        public void Limpar()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            Volumee.Text = "";
        }

        public void Sair()
        {
            DialogResult result;

            result = MessageBox.Show("Tem certeza que deseja sair?",
            "Mensagem do Sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back) && (e.KeyChar != ',') )

            {
                
                e.Handled = true;
                MessageBox.Show("Apenas números e virgulas!");

            }

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            if (!char.IsNumber(e.KeyChar) && !(e.KeyChar == (char)Keys.Back) && (e.KeyChar != ','))

            { 
                e.Handled = true;
                MessageBox.Show("Apenas números e virgulas!");

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CalculoVolume();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Sair();        }

        
    }
}
